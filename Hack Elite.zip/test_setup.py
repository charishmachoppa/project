# test_setup.py

print("Checking required libraries...\n")

try:
    import moviepy
    print("MoviePy installed successfully")
except:
    print("MoviePy NOT installed")

try:
    import whisper
    print("Whisper installed successfully")
except:
    print("Whisper NOT installed")

try:
    from sentence_transformers import SentenceTransformer
    print("Sentence Transformers installed successfully")
except:
    print("Sentence Transformers NOT installed")

try:
    from sklearn.metrics.pairwise import cosine_similarity
    print("Scikit-learn installed successfully")
except:
    print("Scikit-learn NOT installed")

try:
    import torch
    print("PyTorch installed successfully")
except:
    print("PyTorch NOT installed")

print("\nSetup check completed!")