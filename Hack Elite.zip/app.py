from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os, wave, json, torch, subprocess, cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import textwrap
import yt_dlp
from vosk import Model, KaldiRecognizer
from transformers import BertTokenizer, BertModel, pipeline

app = Flask(__name__)
CORS(app)

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
VIDEO_PATH  = os.path.join(BASE_DIR, "video.mp4")
AUDIO_PATH  = os.path.join(BASE_DIR, "audio_converted.wav")
REPORT_PATH = os.path.join(BASE_DIR, "static", "report.png")
MODEL_PATH  = os.path.join(BASE_DIR, "vosk-model-small-en-us-0.15")

os.makedirs(os.path.join(BASE_DIR, "static"), exist_ok=True)

print("Loading BERT models...")
tokenizer  = BertTokenizer.from_pretrained("bert-base-uncased")
bert_model = BertModel.from_pretrained("bert-base-uncased")
fill_mask  = pipeline("fill-mask", model="bert-base-uncased")
print("Models ready!")


# ── Test route ─────────────────────────────────────────────
@app.route("/")
def home():
    return send_file("index.html")


# ── Extract route ───────────────────────────────────────────
@app.route("/extract", methods=["POST", "OPTIONS"])
def extract():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    try:
        # Handle JSON (URL) or FormData (file)
        if request.content_type and "application/json" in request.content_type:
            body = request.get_json(force=True)
            url  = body.get("url", "").strip()
            file = None
        else:
            url  = request.form.get("url", "").strip()
            file = request.files.get("file")

        print(f"Received URL: {url}")
        print(f"Received File: {file}")

        if not url and not file:
            return jsonify({"error": "No URL or file provided"}), 400

        if url:
            print(f"Downloading video: {url}")
            ydl_opts = {
                'format': 'best[ext=mp4]/best',
                'outtmpl': os.path.join(BASE_DIR, 'video.%(ext)s'),
                'noplaylist': True,
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info          = ydl.extract_info(url, download=True)
                video_title   = info.get('title',      'Unknown') or 'Unknown'
                video_duration= int(info.get('duration',   0) or 0)
                video_views   = int(info.get('view_count', 0) or 0)
                video_likes   = int(info.get('like_count', 0) or 0)
                video_channel = info.get('uploader',   'Unknown') or 'Unknown'
                ext           = info.get('ext', 'mp4')
                actual        = os.path.join(BASE_DIR, f"video.{ext}")
                if not os.path.exists(VIDEO_PATH) and os.path.exists(actual):
                    os.rename(actual, VIDEO_PATH)

        elif file:
            file.save(VIDEO_PATH)
            video_title    = file.filename
            video_duration = 0
            video_views    = 0
            video_likes    = 0
            video_channel  = "Uploaded File"

        # Extract audio
        print("Extracting audio with ffmpeg...")
        subprocess.run([
            "ffmpeg", "-y", "-i", VIDEO_PATH,
            "-ar", "16000", "-ac", "1", "-sample_fmt", "s16",
            AUDIO_PATH
        ], check=True)
        print("Audio extracted successfully!")

        return jsonify({
            "status":   "extracted",
            "title":    video_title,
            "channel":  video_channel,
            "duration": f"{video_duration//60}m {video_duration%60}s",
            "views":    f"{video_views:,}",
            "likes":    f"{video_likes:,}",
        })

    except subprocess.CalledProcessError as e:
        print(f"ffmpeg error: {e}")
        return jsonify({"error": "ffmpeg failed. Is ffmpeg installed?"}), 500
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ── Transcribe route ────────────────────────────────────────
@app.route("/transcribe", methods=["POST", "OPTIONS"])
def transcribe():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    try:
        if not os.path.exists(AUDIO_PATH):
            return jsonify({"error": "Audio file not found. Please extract audio first."}), 400

        vosk_model = Model(MODEL_PATH)
        wf  = wave.open(AUDIO_PATH, "rb")
        rec = KaldiRecognizer(vosk_model, wf.getframerate())
        raw_text = ""
        while True:
            chunk = wf.readframes(4000)
            if len(chunk) == 0:
                break
            if rec.AcceptWaveform(chunk):
                raw_text += " " + json.loads(rec.Result()).get("text", "")
        raw_text += " " + json.loads(rec.FinalResult()).get("text", "")
        raw_text = raw_text.strip()
        print(f"Transcription done: {raw_text[:100]}")

        inputs = tokenizer(raw_text, return_tensors="pt",
                           truncation=True, max_length=512, padding=True)
        with torch.no_grad():
            outputs = bert_model(**inputs)
        semantic_vector = outputs.last_hidden_state[:, 0, :]

        words = raw_text.split()
        semantic_words, corrections = [], []
        for i, word in enumerate(words):
            masked = words[:i] + ["[MASK]"] + words[i+1:]
            try:
                pred     = fill_mask(" ".join(masked), top_k=1)
                top_word = pred[0]["token_str"].strip()
                if top_word != word.lower() and pred[0]["score"] > 0.5:
                    corrections.append((word, top_word))
                    semantic_words.append(top_word)
                else:
                    semantic_words.append(word)
            except:
                semantic_words.append(word)
        semantic_text = " ".join(semantic_words)

        cap          = cv2.VideoCapture(VIDEO_PATH)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps          = cap.get(cv2.CAP_PROP_FPS)
        vid_w        = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        vid_h        = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        sample_indices       = np.linspace(0, total_frames-1, 10, dtype=int)
        sampled_frames       = []
        brightness_values    = []
        color_histograms     = []
        dominant_colors_list = []

        for idx in sample_indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ret, frame = cap.read()
            if not ret: continue
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            sampled_frames.append(frame_rgb)
            brightness_values.append(np.mean(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)))
            color_histograms.append((
                cv2.calcHist([frame_rgb],[0],None,[8],[0,256]).flatten(),
                cv2.calcHist([frame_rgb],[1],None,[8],[0,256]).flatten(),
                cv2.calcHist([frame_rgb],[2],None,[8],[0,256]).flatten(),
            ))
            pixels   = frame_rgb.reshape(-1,3).astype(np.float32)
            criteria = (cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,10,1.0)
            _, labels, centers = cv2.kmeans(
                pixels,3,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)
            dominant_colors_list.append(
                centers[np.argmax(np.bincount(labels.flatten()))].astype(int))
        cap.release()

        motion_scores = [
            np.mean(cv2.absdiff(
                cv2.cvtColor(sampled_frames[i-1],cv2.COLOR_RGB2GRAY),
                cv2.cvtColor(sampled_frames[i],  cv2.COLOR_RGB2GRAY)
            )) for i in range(1,len(sampled_frames))
        ]
        edge_densities = [
            np.sum(cv2.Canny(
                cv2.cvtColor(f,cv2.COLOR_RGB2GRAY),100,200)>0
            )/(f.shape[0]*f.shape[1])*100
            for f in sampled_frames
        ]

        fig = plt.figure(figsize=(24,36), facecolor='#0d0d0d')
        fig.suptitle('Video Analysis Report', fontsize=14,
                     color='white', fontweight='bold', y=0.99)
        gs = gridspec.GridSpec(6,4,figure=fig,hspace=0.65,wspace=0.4,
                               top=0.96,bottom=0.02,left=0.07,right=0.97)

        def style_ax(ax, title):
            ax.set_title(title,color='white',fontsize=10,fontweight='bold',pad=6)
            ax.set_facecolor('#1a1a1a')
            ax.tick_params(colors='#aaaaaa',labelsize=7)
            for sp in ax.spines.values():
                sp.set_edgecolor('#333333')

        for i in range(4):
            ax = fig.add_subplot(gs[0,i])
            fi = i*2
            if fi < len(sampled_frames):
                ax.imshow(sampled_frames[fi])
                ts = sample_indices[fi]/fps if fps>0 else 0
                ax.set_title(f"Frame @ {ts:.1f}s",color='#aaaaaa',fontsize=8)
            ax.axis('off')

        time_points = [sample_indices[i]/fps for i in range(len(brightness_values))]

        ax1 = fig.add_subplot(gs[1,:2])
        ax1.plot(time_points,brightness_values,color='#FFD700',linewidth=2,marker='o',markersize=4)
        ax1.fill_between(time_points,brightness_values,alpha=0.2,color='#FFD700')
        ax1.set_xlabel('Time (s)',color='#aaaaaa',fontsize=8)
        ax1.set_ylabel('Brightness',color='#aaaaaa',fontsize=8)
        style_ax(ax1,'Brightness Over Time')

        ax2 = fig.add_subplot(gs[1,2:])
        if motion_scores:
            mt = [sample_indices[i]/fps for i in range(1,len(motion_scores)+1)]
            bw = max((time_points[-1]/max(len(motion_scores),1))*0.6,0.3)
            ax2.bar(mt,motion_scores,color='#FF4444',alpha=0.8,width=bw)
        ax2.set_xlabel('Time (s)',color='#aaaaaa',fontsize=8)
        ax2.set_ylabel('Motion Score',color='#aaaaaa',fontsize=8)
        style_ax(ax2,'Motion Intensity')

        ax3 = fig.add_subplot(gs[2,:2])
        if dominant_colors_list:
            n,sw = len(dominant_colors_list),100
            cc   = np.zeros((100,n*sw,3),dtype=np.uint8)
            for ci,dc in enumerate(dominant_colors_list):
                cc[:,ci*sw:(ci+1)*sw] = np.clip(dc,0,255)
            ax3.imshow(cc,aspect='auto')
            ax3.set_xticks([int((i+0.5)*sw) for i in range(n)])
            ax3.set_xticklabels([f"F{i+1}" for i in range(n)],
                                 color='#aaaaaa',fontsize=7)
        ax3.set_yticks([])
        style_ax(ax3,'Dominant Color Palette Per Frame')

        ax4 = fig.add_subplot(gs[2,2:])
        ax4.plot(time_points,edge_densities,color='#00CFFF',linewidth=2,marker='s',markersize=4)
        ax4.fill_between(time_points,edge_densities,alpha=0.2,color='#00CFFF')
        ax4.set_xlabel('Time (s)',color='#aaaaaa',fontsize=8)
        ax4.set_ylabel('Edge Density (%)',color='#aaaaaa',fontsize=8)
        style_ax(ax4,'Scene Complexity (Edge Density %)')

        ax5 = fig.add_subplot(gs[3,:2])
        if color_histograms:
            ar = np.mean([h[0] for h in color_histograms],axis=0)
            ag = np.mean([h[1] for h in color_histograms],axis=0)
            ab = np.mean([h[2] for h in color_histograms],axis=0)
            ax5.plot(range(len(ar)),ar,color='#FF6B6B',label='Red',  linewidth=2)
            ax5.plot(range(len(ag)),ag,color='#6BFF6B',label='Green',linewidth=2)
            ax5.plot(range(len(ab)),ab,color='#6B9FFF',label='Blue', linewidth=2)
            ax5.legend(fontsize=7,facecolor='#2a2a2a',labelcolor='white')
        style_ax(ax5,'Avg Color Channel Distribution')

        ax6 = fig.add_subplot(gs[3,2:])
        ax6.axis('off')
        ax6.set_facecolor('#1a1a1a')
        meta_lines = [
            ("Resolution", f"{vid_w}x{vid_h}"),
            ("FPS",        f"{fps:.1f}"),
            ("Words",      str(len(raw_text.split()))),
            ("Corrections",str(len(corrections))),
            ("Avg Bright", f"{np.mean(brightness_values):.1f}"),
            ("Avg Motion", f"{np.mean(motion_scores):.2f}" if motion_scores else "N/A"),
        ]
        yp = 0.97
        for lbl,val in meta_lines:
            ax6.text(0.04,yp,f"{lbl}:",transform=ax6.transAxes,fontsize=9,
                     color='#aaaaaa',verticalalignment='top',fontfamily='monospace')
            ax6.text(0.50,yp,val,transform=ax6.transAxes,fontsize=9,
                     color='white',verticalalignment='top',fontfamily='monospace')
            yp -= 0.14
        style_ax(ax6,'Video Stats')

        ax7 = fig.add_subplot(gs[4,:])
        ax7.set_facecolor('#111122')
        ax7.axis('off')
        ax7.text(0.01,0.95,"RAW TRANSCRIPTION:",transform=ax7.transAxes,
                 fontsize=9,color='#FFD700',verticalalignment='top',
                 fontfamily='monospace',fontweight='bold')
        ax7.text(0.01,0.78,
                 textwrap.fill(raw_text[:500]+("..." if len(raw_text)>500 else ""),width=140),
                 transform=ax7.transAxes,fontsize=8,color='#cccccc',
                 verticalalignment='top',fontfamily='monospace')
        style_ax(ax7,'Raw Transcription')

        ax8 = fig.add_subplot(gs[5,:])
        ax8.set_facecolor('#111122')
        ax8.axis('off')
        ax8.text(0.01,0.95,"SEMANTIC TEXT:",transform=ax8.transAxes,
                 fontsize=9,color='#53d8fb',verticalalignment='top',
                 fontfamily='monospace',fontweight='bold')
        ax8.text(0.01,0.78,
                 textwrap.fill(semantic_text[:500]+("..." if len(semantic_text)>500 else ""),width=140),
                 transform=ax8.transAxes,fontsize=8,color='#cccccc',
                 verticalalignment='top',fontfamily='monospace')
        style_ax(ax8,'Semantic Analysis')

        plt.savefig(REPORT_PATH,dpi=120,bbox_inches='tight',
                    facecolor='#0d0d0d',edgecolor='none')
        plt.close()

        return jsonify({
            "status":        "done",
            "raw_text":      raw_text,
            "semantic_text": semantic_text,
            "corrections":   len(corrections),
            "words":         len(raw_text.split()),
            "resolution":    f"{vid_w}x{vid_h}",
            "fps":           round(fps,1),
            "report_url":    "/static/report.png"
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_file(os.path.join(BASE_DIR,"static",filename))


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)