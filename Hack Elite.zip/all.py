import yt_dlp
import os
import wave
import json
import torch
import subprocess
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import textwrap
from vosk import Model, KaldiRecognizer
from transformers import BertTokenizer, BertModel, pipeline

# ==================================================
# STEP 1: Download Audio + Video from YouTube
# ==================================================
url = input("Enter YouTube video/shorts URL: ")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIDEO_PATH = os.path.join(BASE_DIR, "video.mp4")
CONVERTED_AUDIO = os.path.join(BASE_DIR, "audio_converted.wav")
FRAMES_DIR = os.path.join(BASE_DIR, "frames")
os.makedirs(FRAMES_DIR, exist_ok=True)

ydl_opts_video = {
    'format': 'best[ext=mp4]/best',
    'outtmpl': os.path.join(BASE_DIR, 'video.%(ext)s'),
    'noplaylist': True,
}

print("\nDownloading video from YouTube...")
with yt_dlp.YoutubeDL(ydl_opts_video) as ydl:
    info = ydl.extract_info(url, download=True)
    video_title    = info.get('title', 'Unknown Title') or 'Unknown Title'
    video_duration = int(info.get('duration', 0) or 0)
    video_views    = int(info.get('view_count', 0) or 0)
    video_likes    = int(info.get('like_count', 0) or 0)
    video_channel  = info.get('uploader', 'Unknown') or 'Unknown'

ext = info.get('ext', 'mp4')
actual_video = os.path.join(BASE_DIR, f"video.{ext}")
if not os.path.exists(VIDEO_PATH) and os.path.exists(actual_video):
    os.rename(actual_video, VIDEO_PATH)

print(f"Downloaded: {video_title}")

# ==================================================
# STEP 2: Extract Audio and Convert
# ==================================================
print("\nExtracting and converting audio...")

try:
    subprocess.run([
        "ffmpeg", "-y", "-i", VIDEO_PATH,
        "-ar", "16000", "-ac", "1", "-sample_fmt", "s16",
        CONVERTED_AUDIO
    ], check=True)
    print("Audio extracted via ffmpeg!")

except FileNotFoundError:
    print("ffmpeg not found, using moviepy fallback...")
    try:
        from moviepy import VideoFileClip
    except ImportError:
        raise ImportError(
            "\n[ERROR] Neither ffmpeg nor moviepy is available."
            "\n► Install moviepy: pip install moviepy"
            "\n► Or install ffmpeg from: https://www.gyan.dev/ffmpeg/builds/"
        )
    clip = VideoFileClip(VIDEO_PATH)
    TEMP_AUDIO = os.path.join(BASE_DIR, "audio_temp.wav")
    clip.audio.write_audiofile(TEMP_AUDIO, fps=16000, nbytes=2,
                               ffmpeg_params=["-ac", "1"])
    clip.close()
    os.rename(TEMP_AUDIO, CONVERTED_AUDIO)
    print("Audio extracted via moviepy!")

print("Audio ready!")

# ==================================================
# STEP 3: Speech Recognition with Vosk
# ==================================================
MODEL_PATH = os.path.join(BASE_DIR, "vosk-model-small-en-us-0.15")
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(
        f"\n[ERROR] Vosk model not found at: {MODEL_PATH}"
        f"\n► Download from: https://alphacephei.com/vosk/models"
    )

print(f"\nLoading Vosk model...")
vosk_model = Model(MODEL_PATH)
wf = wave.open(CONVERTED_AUDIO, "rb")
rec = KaldiRecognizer(vosk_model, wf.getframerate())

print("Transcribing speech...")
raw_text = ""
while True:
    data = wf.readframes(4000)
    if len(data) == 0:
        break
    if rec.AcceptWaveform(data):
        result = json.loads(rec.Result())
        text = result.get("text", "")
        raw_text += " " + text
        print("  Partial:", text)

final_result = json.loads(rec.FinalResult())
raw_text += " " + final_result.get("text", "")
raw_text = raw_text.strip()
print("\nFinal Transcription:", raw_text)

# ==================================================
# STEP 4: BERT Semantic Analysis
# ==================================================
print("\nRunning BERT semantic analysis...")
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
bert_model = BertModel.from_pretrained("bert-base-uncased")

inputs = tokenizer(raw_text, return_tensors="pt", truncation=True,
                   max_length=512, padding=True)
with torch.no_grad():
    outputs = bert_model(**inputs)

semantic_vector = outputs.last_hidden_state[:, 0, :]

fill_mask = pipeline("fill-mask", model="bert-base-uncased")
words = raw_text.split()
semantic_words = []
corrections = []

for i, word in enumerate(words):
    masked = words[:i] + ["[MASK]"] + words[i+1:]
    masked_sentence = " ".join(masked)
    try:
        predictions = fill_mask(masked_sentence, top_k=1)
        top_word = predictions[0]["token_str"].strip()
        if top_word != word.lower() and predictions[0]["score"] > 0.5:
            corrections.append((word, top_word))
            semantic_words.append(top_word)
        else:
            semantic_words.append(word)
    except Exception:
        semantic_words.append(word)

semantic_text = " ".join(semantic_words)

# ==================================================
# STEP 5: Visual Analysis of Video Frames
# ==================================================
print("\nAnalyzing video frames...")
cap = cv2.VideoCapture(VIDEO_PATH)

total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
fps          = cap.get(cv2.CAP_PROP_FPS)
width        = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height       = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

sample_indices       = np.linspace(0, total_frames - 1, 10, dtype=int)
sampled_frames       = []
brightness_values    = []
color_histograms     = []
dominant_colors_list = []

for idx in sample_indices:
    cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
    ret, frame = cap.read()
    if not ret:
        continue

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    sampled_frames.append(frame_rgb)

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    brightness_values.append(np.mean(gray))

    hist_r = cv2.calcHist([frame_rgb], [0], None, [8], [0, 256]).flatten()
    hist_g = cv2.calcHist([frame_rgb], [1], None, [8], [0, 256]).flatten()
    hist_b = cv2.calcHist([frame_rgb], [2], None, [8], [0, 256]).flatten()
    color_histograms.append((hist_r, hist_g, hist_b))

    pixels   = frame_rgb.reshape(-1, 3).astype(np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    _, labels, centers = cv2.kmeans(pixels, 3, None, criteria, 10,
                                    cv2.KMEANS_RANDOM_CENTERS)
    dominant = centers[np.argmax(np.bincount(labels.flatten()))].astype(int)
    dominant_colors_list.append(dominant)

cap.release()

motion_scores = []
for i in range(1, len(sampled_frames)):
    prev = cv2.cvtColor(sampled_frames[i-1], cv2.COLOR_RGB2GRAY)
    curr = cv2.cvtColor(sampled_frames[i],   cv2.COLOR_RGB2GRAY)
    diff = cv2.absdiff(prev, curr)
    motion_scores.append(np.mean(diff))

edge_densities = []
for frame in sampled_frames:
    gray  = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    edge_densities.append(np.sum(edges > 0) / edges.size * 100)

# ==================================================
# STEP 6: Generate Visual Analysis Report (FIXED)
# ==================================================
print("\nGenerating visual analysis report...")

fig = plt.figure(figsize=(24, 36), facecolor='#0d0d0d')

short_title = video_title[:60] + "..." if len(video_title) > 60 else video_title
fig.suptitle(f'Video Analysis Report\n"{short_title}"',
             fontsize=14, color='white', fontweight='bold', y=0.99)

gs = gridspec.GridSpec(6, 4, figure=fig, hspace=0.65, wspace=0.4,
                       top=0.96, bottom=0.02, left=0.07, right=0.97)

# --- Row 1: Sampled Frames ---
for i in range(4):
    ax = fig.add_subplot(gs[0, i])
    frame_idx = i * 2
    if frame_idx < len(sampled_frames):
        ax.imshow(sampled_frames[frame_idx])
        timestamp = (sample_indices[frame_idx] / fps) if fps > 0 else 0
        ax.set_title(f"Frame @ {timestamp:.1f}s", color='#aaaaaa',
                     fontsize=8, pad=4)
    ax.axis('off')

# --- Row 2: Brightness Over Time ---
ax_bright = fig.add_subplot(gs[1, :2])
time_points = [sample_indices[i] / fps for i in range(len(brightness_values))]
ax_bright.plot(time_points, brightness_values, color='#FFD700',
               linewidth=2, marker='o', markersize=4)
ax_bright.fill_between(time_points, brightness_values, alpha=0.2, color='#FFD700')
ax_bright.set_title('Brightness Over Time', color='white', fontsize=10,
                    fontweight='bold', pad=6)
ax_bright.set_xlabel('Time (seconds)', color='#aaaaaa', fontsize=8)
ax_bright.set_ylabel('Brightness',     color='#aaaaaa', fontsize=8)
ax_bright.set_facecolor('#1a1a1a')
ax_bright.tick_params(colors='#aaaaaa', labelsize=7)
for spine in ax_bright.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 2: Motion Intensity ---
ax_motion = fig.add_subplot(gs[1, 2:])
if len(motion_scores) > 0:
    motion_times = [sample_indices[i] / fps for i in range(1, len(motion_scores) + 1)]
    bar_width    = max((time_points[-1] / max(len(motion_scores), 1)) * 0.6, 0.3)
    ax_motion.bar(motion_times, motion_scores, color='#FF4444',
                  alpha=0.8, width=bar_width)
ax_motion.set_title('Motion Intensity', color='white', fontsize=10,
                    fontweight='bold', pad=6)
ax_motion.set_xlabel('Time (seconds)', color='#aaaaaa', fontsize=8)
ax_motion.set_ylabel('Motion Score',   color='#aaaaaa', fontsize=8)
ax_motion.set_facecolor('#1a1a1a')
ax_motion.tick_params(colors='#aaaaaa', labelsize=7)
for spine in ax_motion.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 3: Dominant Color Palette (FIXED) ---
ax_colors = fig.add_subplot(gs[2, :2])
if len(dominant_colors_list) > 0:
    n_colors     = len(dominant_colors_list)
    swatch_w     = 100
    canvas_w     = n_colors * swatch_w
    color_canvas = np.zeros((100, canvas_w, 3), dtype=np.uint8)
    for ci, dc in enumerate(dominant_colors_list):
        color_canvas[:, ci*swatch_w:(ci+1)*swatch_w] = np.clip(dc, 0, 255)
    ax_colors.imshow(color_canvas, aspect='auto')
    ax_colors.set_xticks([int((i + 0.5) * swatch_w) for i in range(n_colors)])
    ax_colors.set_xticklabels([f"F{i+1}" for i in range(n_colors)],
                               color='#aaaaaa', fontsize=7)
ax_colors.set_title('Dominant Color Palette Per Frame', color='white',
                    fontsize=10, fontweight='bold', pad=6)
ax_colors.set_yticks([])
for spine in ax_colors.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 3: Edge Density ---
ax_edge = fig.add_subplot(gs[2, 2:])
ax_edge.plot(time_points, edge_densities, color='#00CFFF',
             linewidth=2, marker='s', markersize=4)
ax_edge.fill_between(time_points, edge_densities, alpha=0.2, color='#00CFFF')
ax_edge.set_title('Scene Complexity (Edge Density %)', color='white',
                  fontsize=10, fontweight='bold', pad=6)
ax_edge.set_xlabel('Time (seconds)',   color='#aaaaaa', fontsize=8)
ax_edge.set_ylabel('Edge Density (%)', color='#aaaaaa', fontsize=8)
ax_edge.set_facecolor('#1a1a1a')
ax_edge.tick_params(colors='#aaaaaa', labelsize=7)
for spine in ax_edge.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 4: RGB Distribution ---
ax_rgb = fig.add_subplot(gs[3, :2])
if len(color_histograms) > 0:
    avg_r = np.mean([h[0] for h in color_histograms], axis=0)
    avg_g = np.mean([h[1] for h in color_histograms], axis=0)
    avg_b = np.mean([h[2] for h in color_histograms], axis=0)
    bins  = range(len(avg_r))
    ax_rgb.plot(bins, avg_r, color='#FF6B6B', label='Red',   linewidth=2)
    ax_rgb.plot(bins, avg_g, color='#6BFF6B', label='Green', linewidth=2)
    ax_rgb.plot(bins, avg_b, color='#6B9FFF', label='Blue',  linewidth=2)
ax_rgb.set_title('Avg Color Channel Distribution', color='white',
                 fontsize=10, fontweight='bold', pad=6)
ax_rgb.set_facecolor('#1a1a1a')
ax_rgb.tick_params(colors='#aaaaaa', labelsize=7)
ax_rgb.legend(fontsize=7, facecolor='#2a2a2a', labelcolor='white')
for spine in ax_rgb.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 4: Metadata (FIXED — no overlap) ---
ax_meta = fig.add_subplot(gs[3, 2:])
ax_meta.set_facecolor('#1a1a1a')
ax_meta.axis('off')
meta_lines = [
    ("Title",       short_title[:32] + ("..." if len(short_title) > 32 else "")),
    ("Channel",     str(video_channel)[:28]),
    ("Duration",    f"{video_duration // 60}m {video_duration % 60}s"),
    ("Views",       f"{video_views:,}"),
    ("Likes",       f"{video_likes:,}"),
    ("FPS",         f"{fps:.1f}"),
    ("Resolution",  f"{width}x{height}"),
    ("Words",       str(len(raw_text.split()))),
    ("Corrections", str(len(corrections))),
]
y_pos = 0.97
for label, value in meta_lines:
    ax_meta.text(0.04, y_pos, f"{label}:", transform=ax_meta.transAxes,
                 fontsize=9, color='#aaaaaa', verticalalignment='top',
                 fontfamily='monospace')
    ax_meta.text(0.40, y_pos, value, transform=ax_meta.transAxes,
                 fontsize=9, color='white', verticalalignment='top',
                 fontfamily='monospace')
    y_pos -= 0.105
ax_meta.set_title('Video Metadata', color='white', fontsize=10,
                  fontweight='bold', pad=6)
for spine in ax_meta.spines.values():
    spine.set_edgecolor('#333333')

# --- Row 5: Raw Transcription (SEPARATE ROW) ---
ax_raw = fig.add_subplot(gs[4, :])
ax_raw.set_facecolor('#111122')
ax_raw.axis('off')
display_raw  = raw_text[:500] + "..." if len(raw_text) > 500 else raw_text
wrapped_raw  = textwrap.fill(display_raw, width=140)
ax_raw.text(0.01, 0.95, "RAW TRANSCRIPTION:", transform=ax_raw.transAxes,
            fontsize=9, color='#FFD700', verticalalignment='top',
            fontfamily='monospace', fontweight='bold')
ax_raw.text(0.01, 0.78, wrapped_raw, transform=ax_raw.transAxes,
            fontsize=8, color='#cccccc', verticalalignment='top',
            fontfamily='monospace', wrap=True)
ax_raw.set_title('Raw Transcription', color='white', fontsize=10,
                 fontweight='bold', pad=6)
for spine in ax_raw.spines.values():
    spine.set_edgecolor('#444466')

# --- Row 6: Semantic Text (SEPARATE ROW) ---
ax_sem = fig.add_subplot(gs[5, :])
ax_sem.set_facecolor('#111122')
ax_sem.axis('off')
display_sem  = semantic_text[:500] + "..." if len(semantic_text) > 500 else semantic_text
wrapped_sem  = textwrap.fill(display_sem, width=140)
ax_sem.text(0.01, 0.95, "SEMANTIC TEXT:", transform=ax_sem.transAxes,
            fontsize=9, color='#53d8fb', verticalalignment='top',
            fontfamily='monospace', fontweight='bold')
ax_sem.text(0.01, 0.78, wrapped_sem, transform=ax_sem.transAxes,
            fontsize=8, color='#cccccc', verticalalignment='top',
            fontfamily='monospace', wrap=True)
ax_sem.set_title('Semantic Analysis', color='white', fontsize=10,
                 fontweight='bold', pad=6)
for spine in ax_sem.spines.values():
    spine.set_edgecolor('#444466')

# Save
REPORT_PATH = os.path.join(BASE_DIR, "video_analysis_report.png")
plt.savefig(REPORT_PATH, dpi=150, bbox_inches='tight',
            facecolor='#0d0d0d', edgecolor='none')
plt.show()
print(f"\nReport saved to: {REPORT_PATH}")

# ==================================================
# FINAL SUMMARY
# ==================================================
print("\n" + "="*55)
print("  COMPLETE ANALYSIS SUMMARY")
print("="*55)
print(f"  Title         : {video_title}")
print(f"  Channel       : {video_channel}")
print(f"  Duration      : {video_duration // 60}m {video_duration % 60}s")
print(f"  Resolution    : {width}x{height} @ {fps:.1f}fps")
print(f"  Avg Brightness: {np.mean(brightness_values):.1f}")
print(f"  Avg Motion    : {np.mean(motion_scores):.2f}")
print(f"  Avg Complexity: {np.mean(edge_densities):.2f}%")
print(f"  Words Found   : {len(raw_text.split())}")
print(f"  Corrections   : {len(corrections)}")
print(f"\n  Raw Text      : {raw_text[:100]}...")
print(f"  Semantic Text : {semantic_text[:100]}...")
print(f"\n  Vector Shape  : {semantic_vector.shape}")
print(f"  Report Saved  : {REPORT_PATH}")
print("="*55)